import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Copy, Download, Pencil } from "lucide-react";
import { useMemo } from "react";
import { toast } from "sonner";
import { AppShell } from "@/components/app-shell";
import { QrImage, downloadQr } from "@/components/qr-block";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/menu/live")({ component: MenuLivePage });

function menuUrl() {
  if (typeof window === "undefined") return "https://druto.in/m";
  return `${window.location.origin}/m`;
}

function MenuLivePage() {
  const navigate = useNavigate();
  const business = useAppStore((s) => s.business);
  const url = useMemo(() => menuUrl(), []);

  return (
    <AppShell hideStats>
      <div className="w-full mx-auto pb-8 animate-fade-in">
        <button
          type="button"
          onClick={() => navigate({ to: "/offers" })}
          className="flex items-center gap-1.5 mt-1 text-muted text-sm min-h-11"
        >
          <ChevronLeft className="size-4" /> Back
        </button>
        <div className="mb-6 mt-2">
          <h1 className="text-2xl">Digital menu</h1>
          <p className="text-sm text-muted mt-1">Live and ready for guests.</p>
        </div>
        <div className="panel-lg p-6">
          <div className="flex justify-center mb-6">
            <div className="qr-plate size-64">
              <QrImage value={url} alt="Digital Menu QR" className="size-full object-contain" />
            </div>
          </div>
          <div className="bg-elevated rounded-lg p-4 flex items-center justify-between gap-4 mb-4">
            <div className="overflow-hidden min-w-0">
              <p className="eyebrow mb-1">Shareable link</p>
              <p className="text-sm truncate select-all">{url}</p>
            </div>
            <button
              type="button"
              title="Copy link"
              onClick={() => {
                void navigator.clipboard.writeText(url);
                toast.success("Menu link copied");
              }}
              className="size-11 bg-surface rounded-md flex items-center justify-center shadow-card shrink-0"
            >
              <Copy className="size-4" />
            </button>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={() => downloadQr(url, `${business.name}-menu-qr.png`)}
              className="btn-primary flex-1"
            >
              <Download className="size-4" /> Download QR
            </button>
            <button type="button" onClick={() => navigate({ to: "/menu/edit" })} className="btn-ghost flex-1">
              <Pencil className="size-4" /> Edit menu
            </button>
          </div>
        </div>
        <button
          type="button"
          onClick={() => navigate({ to: "/m" })}
          className="mt-3 panel w-full p-4 flex items-center justify-between"
        >
          <div>
            <p className="font-medium text-sm">Preview as a guest</p>
            <p className="text-sm text-muted mt-0.5">Open the live menu</p>
          </div>
          <ChevronRight className="size-4 text-muted" />
        </button>
      </div>
    </AppShell>
  );
}
