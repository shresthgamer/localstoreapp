import { useEffect, useState } from "react";

export function usePublicUrl(path: string) {
  const [url, setUrl] = useState(path);
  useEffect(() => {
    setUrl(`${window.location.origin}${path.startsWith("/") ? path : `/${path}`}`);
  }, [path]);
  return url;
}

export async function copyText(text: string): Promise<boolean> {
  if (typeof window === "undefined" || !text) return false;
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* iframe / permissions — fall through */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.top = "0";
    ta.style.left = "0";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    ta.setSelectionRange(0, text.length);
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  } catch {
    return false;
  }
}

function clickAnchor(href: string, download?: string) {
  const a = document.createElement("a");
  a.href = href;
  if (download) a.download = download;
  a.rel = "noopener";
  a.style.display = "none";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

export async function triggerDownload(filename: string, dataUrl: string): Promise<boolean> {
  try {
    const res = await fetch(dataUrl);
    const blob = await res.blob();
    const objectUrl = URL.createObjectURL(blob);
    clickAnchor(objectUrl, filename);
    window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
    return true;
  } catch {
    try {
      clickAnchor(dataUrl, filename);
      return true;
    } catch {
      return false;
    }
  }
}

export function shareMessage(businessName: string, url: string) {
  return `Scan to collect rewards at ${businessName}: ${url}`;
}

export function whatsappHref(text: string) {
  return `https://wa.me/?text=${encodeURIComponent(text)}`;
}

export function smsHref(text: string) {
  return `sms:?body=${encodeURIComponent(text)}`;
}

export function mailtoHref(subject: string, text: string) {
  return `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
}
