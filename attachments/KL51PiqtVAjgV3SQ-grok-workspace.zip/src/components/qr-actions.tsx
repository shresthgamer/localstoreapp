import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Check, Copy, Download, Eye, Monitor, Share2 } from "lucide-react";
import { toast } from "sonner";
import { copyText, mailtoHref, shareMessage, smsHref, whatsappHref } from "@/lib/actions";
import { downloadQr, useQrDataUrl } from "@/components/qr-block";
import { Overlay } from "@/components/ui-bits";

export function QrActions({
  url,
  businessName,
  filename,
}: {
  url: string;
  businessName: string;
  filename: string;
}) {
  const [copied, setCopied] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const qrSrc = useQrDataUrl(url, 720);
  const message = shareMessage(businessName, url);

  async function onCopy() {
    const ok = await copyText(url);
    if (ok) {
      setCopied(true);
      toast.success("Link copied");
      window.setTimeout(() => setCopied(false), 2000);
      return;
    }
    setShareOpen(true);
    toast.message("Select the link and copy it");
  }

  async function onShare() {
    if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
      try {
        await navigator.share({ title: businessName, text: message, url });
        toast.success("Shared");
        return;
      } catch (err) {
        if (err instanceof Error && err.name === "AbortError") return;
      }
    }
    setShareOpen(true);
  }

  async function onDownload() {
    setSaving(true);
    try {
      const result = await downloadQr(url, filename);
      if (result.ok) {
        toast.success("QR image saved");
      } else {
        setSaveOpen(true);
        toast.message("Press and hold the QR to save it");
      }
    } catch {
      setSaveOpen(true);
      toast.message("Press and hold the QR to save it");
    } finally {
      setSaving(false);
    }
  }

  function selectLink(el: HTMLInputElement) {
    el.focus();
    el.select();
  }

  return (
    <div className="relative z-20 space-y-3">
      <label className="block">
        <span className="text-xs font-medium uppercase tracking-widest text-muted">Guest link</span>
        <input
          readOnly
          value={url}
          onFocus={(e) => selectLink(e.currentTarget)}
          onClick={(e) => selectLink(e.currentTarget)}
          className="field mt-1 text-sm"
          aria-label="Guest reward link"
        />
      </label>

      <Link to="/c" search={{ preview: true }} className="btn-primary w-full">
        <Eye className="size-4" /> See what guests see
      </Link>

      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => void onCopy()} className="btn-ghost">
          {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
          {copied ? "Copied" : "Copy"}
        </button>
        <button type="button" onClick={() => void onShare()} className="btn-ghost">
          <Share2 className="size-4" /> Share
        </button>
        <button type="button" onClick={() => void onDownload()} className="btn-ghost" disabled={saving}>
          <Download className="size-4" /> {saving ? "Saving…" : "Download"}
        </button>
        <Link to="/presenter" className="btn-ghost">
          <Monitor className="size-4" /> Presenter
        </Link>
      </div>

      <Overlay open={shareOpen} onClose={() => setShareOpen(false)}>
        <div className="p-5 space-y-3">
          <h2 className="text-lg">Share your QR</h2>
          <p className="text-sm text-muted">Send this link so guests land on your stamp page.</p>
          <input
            readOnly
            value={url}
            onFocus={(e) => selectLink(e.currentTarget)}
            onClick={(e) => selectLink(e.currentTarget)}
            className="field text-sm"
          />
          <button type="button" onClick={() => void onCopy()} className="btn-primary w-full">
            <Copy className="size-4" /> Copy link
          </button>
          <a href={whatsappHref(message)} target="_blank" rel="noreferrer" className="btn-ghost w-full">
            WhatsApp
          </a>
          <a href={smsHref(message)} className="btn-ghost w-full">
            Messages
          </a>
          <a href={mailtoHref(`${businessName} rewards`, message)} className="btn-ghost w-full">
            Email
          </a>
          <Link to="/c" search={{ preview: true }} className="btn-ghost w-full" onClick={() => setShareOpen(false)}>
            <Eye className="size-4" /> Open guest view
          </Link>
        </div>
      </Overlay>

      <Overlay open={saveOpen} onClose={() => setSaveOpen(false)}>
        <div className="p-5 space-y-3">
          <h2 className="text-lg">Save QR code</h2>
          <p className="text-sm text-muted">If the file did not download, press and hold the image, then save it.</p>
          {qrSrc ? <img src={qrSrc} alt="Business QR Code" className="w-full rounded-xl border border-border bg-surface" /> : null}
          <button type="button" onClick={() => void onDownload()} className="btn-primary w-full">
            <Download className="size-4" /> Try download again
          </button>
        </div>
      </Overlay>
    </div>
  );
}
