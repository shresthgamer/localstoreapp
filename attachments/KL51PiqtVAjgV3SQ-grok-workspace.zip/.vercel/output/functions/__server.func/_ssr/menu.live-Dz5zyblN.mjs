import { i as __toESM } from "../_runtime.mjs";
import { B as require_jsx_runtime, V as require_react, b as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as useAppStore } from "./store-WCxR1Lzm.mjs";
import { B as ChevronRight, F as Download, I as Copy, S as Pencil, V as ChevronLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as AppShell } from "./app-shell-XXc-0SlW.mjs";
import { n as downloadQr, t as QrImage } from "./qr-block-3CWDNUlT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/menu.live-Dz5zyblN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function menuUrl() {
	if (typeof window === "undefined") return "https://druto.in/m";
	return `${window.location.origin}/m`;
}
function MenuLivePage() {
	const navigate = useNavigate();
	const business = useAppStore((s) => s.business);
	const url = (0, import_react.useMemo)(() => menuUrl(), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		hideStats: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full mx-auto pb-8 animate-fade-in",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => navigate({ to: "/offers" }),
					className: "flex items-center gap-1.5 mt-1 text-muted text-sm min-h-11",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" }), " Back"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-6 mt-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl",
						children: "Digital menu"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted mt-1",
						children: "Live and ready for guests."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel-lg p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex justify-center mb-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "qr-plate size-64",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrImage, {
									value: url,
									alt: "Digital Menu QR",
									className: "size-full object-contain"
								})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-elevated rounded-lg p-4 flex items-center justify-between gap-4 mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "overflow-hidden min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "eyebrow mb-1",
									children: "Shareable link"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm truncate select-all",
									children: url
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								title: "Copy link",
								onClick: () => {
									navigator.clipboard.writeText(url);
									toast.success("Menu link copied");
								},
								className: "size-11 bg-surface rounded-md flex items-center justify-center shadow-card shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col sm:flex-row gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => downloadQr(url, `${business.name}-menu-qr.png`),
								className: "btn-primary flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), " Download QR"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => navigate({ to: "/menu/edit" }),
								className: "btn-ghost flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" }), " Edit menu"]
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => navigate({ to: "/m" }),
					className: "mt-3 panel w-full p-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium text-sm",
						children: "Preview as a guest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted mt-0.5",
						children: "Open the live menu"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted" })]
				})
			]
		})
	});
}
//#endregion
export { MenuLivePage as component };
