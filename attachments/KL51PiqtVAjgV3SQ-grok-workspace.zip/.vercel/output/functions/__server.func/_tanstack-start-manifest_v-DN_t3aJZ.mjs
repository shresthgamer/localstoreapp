//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DN_t3aJZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/c",
			"/customers",
			"/m",
			"/offers",
			"/presenter",
			"/scratch",
			"/settings",
			"/stamp",
			"/winners",
			"/menu/edit",
			"/menu/live"
		],
		preloads: ["/assets/index-B6RN2QUR.js", "/assets/createLucideIcon-ClDLAYYk.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-B6RN2QUR.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DgOtB9FJ.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/copy-BLeckl4K.js",
			"/assets/download-DL4mRSlA.js",
			"/assets/star-ok2RbCg4.js",
			"/assets/store-D01kKWeF.js",
			"/assets/qr-block-C5pnzPCg.js"
		]
	},
	"/c": {
		filePath: "/workspace/src/routes/c.tsx",
		children: void 0,
		preloads: [
			"/assets/c-DXws1XHN.js",
			"/assets/check-tkV_b00u.js",
			"/assets/chevron-right-Vw_JLXcG.js",
			"/assets/business-profile-sWd29H77.js",
			"/assets/gift-xIvPh9Uh.js",
			"/assets/map-pin-msF_1Niw.js",
			"/assets/store-8zPr1_H3.js",
			"/assets/store-D01kKWeF.js"
		]
	},
	"/customers": {
		filePath: "/workspace/src/routes/customers.tsx",
		children: void 0,
		preloads: [
			"/assets/customers-IKLjSDxa.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/download-DL4mRSlA.js",
			"/assets/plus-CrE_rBvv.js",
			"/assets/search-DOZSMaLM.js",
			"/assets/store-D01kKWeF.js",
			"/assets/ui-bits-DIZnL0cv.js"
		]
	},
	"/m": {
		filePath: "/workspace/src/routes/m.tsx",
		children: void 0,
		preloads: [
			"/assets/m-BzmQdXFQ.js",
			"/assets/business-profile-sWd29H77.js",
			"/assets/store-D01kKWeF.js",
			"/assets/ui-bits-DIZnL0cv.js"
		]
	},
	"/offers": {
		filePath: "/workspace/src/routes/offers.tsx",
		children: void 0,
		preloads: [
			"/assets/offers-CoZTW0ap.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/store-8zPr1_H3.js",
			"/assets/store-D01kKWeF.js"
		]
	},
	"/presenter": {
		filePath: "/workspace/src/routes/presenter.tsx",
		children: void 0,
		preloads: [
			"/assets/presenter-B-pvkQZK.js",
			"/assets/chevron-left-2fYFS0EV.js",
			"/assets/store-D01kKWeF.js",
			"/assets/ui-bits-DIZnL0cv.js",
			"/assets/qr-block-C5pnzPCg.js"
		]
	},
	"/scratch": {
		filePath: "/workspace/src/routes/scratch.tsx",
		children: void 0,
		preloads: [
			"/assets/scratch-D-jPIz8M.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/chevron-left-2fYFS0EV.js",
			"/assets/trash-2-Cw0jH8Oe.js",
			"/assets/phone-preview-D6wBTR1Z.js",
			"/assets/store-D01kKWeF.js",
			"/assets/ui-bits-DIZnL0cv.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-yd0Z364_.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/check-tkV_b00u.js",
			"/assets/chevron-right-Vw_JLXcG.js",
			"/assets/download-DL4mRSlA.js",
			"/assets/map-pin-msF_1Niw.js",
			"/assets/star-ok2RbCg4.js",
			"/assets/store-D01kKWeF.js",
			"/assets/ui-bits-DIZnL0cv.js"
		]
	},
	"/stamp": {
		filePath: "/workspace/src/routes/stamp.tsx",
		children: void 0,
		preloads: [
			"/assets/stamp-B9TeyK-P.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/chevron-left-2fYFS0EV.js",
			"/assets/plus-CrE_rBvv.js",
			"/assets/trash-2-Cw0jH8Oe.js",
			"/assets/phone-preview-D6wBTR1Z.js",
			"/assets/store-D01kKWeF.js",
			"/assets/ui-bits-DIZnL0cv.js"
		]
	},
	"/winners": {
		filePath: "/workspace/src/routes/winners.tsx",
		children: void 0,
		preloads: [
			"/assets/winners-xEZ3BjvC.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/gift-xIvPh9Uh.js",
			"/assets/search-DOZSMaLM.js",
			"/assets/store-D01kKWeF.js"
		]
	},
	"/menu/edit": {
		filePath: "/workspace/src/routes/menu.edit.tsx",
		children: void 0,
		preloads: [
			"/assets/menu.edit-D_bhzIks.js",
			"/assets/chevron-left-2fYFS0EV.js",
			"/assets/plus-CrE_rBvv.js",
			"/assets/trash-2-Cw0jH8Oe.js",
			"/assets/store-D01kKWeF.js",
			"/assets/ui-bits-DIZnL0cv.js"
		]
	},
	"/menu/live": {
		filePath: "/workspace/src/routes/menu.live.tsx",
		children: void 0,
		preloads: [
			"/assets/menu.live-D07dOirF.js",
			"/assets/app-shell-DnXDYHrs.js",
			"/assets/chevron-left-2fYFS0EV.js",
			"/assets/chevron-right-Vw_JLXcG.js",
			"/assets/copy-BLeckl4K.js",
			"/assets/download-DL4mRSlA.js",
			"/assets/store-D01kKWeF.js",
			"/assets/qr-block-C5pnzPCg.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
